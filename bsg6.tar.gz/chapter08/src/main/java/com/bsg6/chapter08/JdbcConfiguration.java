package com.bsg6.chapter08;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcConfiguration {
}
