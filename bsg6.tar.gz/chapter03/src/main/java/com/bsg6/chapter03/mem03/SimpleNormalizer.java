package com.bsg6.chapter03.mem03;

import com.bsg6.chapter03.Normalizer;
import org.springframework.stereotype.Component;

@Component("foo")
public class SimpleNormalizer implements Normalizer {
}
