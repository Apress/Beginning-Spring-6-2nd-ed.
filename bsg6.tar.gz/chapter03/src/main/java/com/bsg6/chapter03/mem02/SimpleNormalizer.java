package com.bsg6.chapter03.mem02;

import com.bsg6.chapter03.Normalizer;
import org.springframework.stereotype.Component;

@Component
public class SimpleNormalizer implements Normalizer {
    /* inherits default transform() method from interface */
}
