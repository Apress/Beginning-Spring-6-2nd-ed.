package com.bsg6.chapter03;

public interface Resettable {
    void reset();
}
