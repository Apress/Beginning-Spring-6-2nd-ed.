package com.bsg6.chapter03.mem01;

import com.bsg6.chapter03.AbstractMusicService;
import org.springframework.stereotype.Component;

@Component
public class MusicService1 extends AbstractMusicService {
}
