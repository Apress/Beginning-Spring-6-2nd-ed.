package com.bsg6.chapter11.song;

public record VoteDTO(Integer songId) {
}
