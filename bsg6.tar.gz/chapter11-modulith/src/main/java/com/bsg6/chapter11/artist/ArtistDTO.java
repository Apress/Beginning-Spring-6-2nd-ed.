package com.bsg6.chapter11.artist;

public record ArtistDTO(Integer id, String name) {
}
