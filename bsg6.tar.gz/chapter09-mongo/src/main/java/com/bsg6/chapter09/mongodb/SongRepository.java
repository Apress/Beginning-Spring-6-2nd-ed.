package com.bsg6.chapter09.mongodb;

import com.bsg6.chapter09.common.BaseSongRepository;

public interface SongRepository
    extends BaseSongRepository<Artist, Song, String> {
}

