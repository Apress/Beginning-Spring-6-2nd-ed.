package com.bsg6.chapter09.mongodb;

import com.bsg6.chapter09.common.BaseArtistRepository;

public interface ArtistRepository
    extends BaseArtistRepository<Artist, String> {
}
