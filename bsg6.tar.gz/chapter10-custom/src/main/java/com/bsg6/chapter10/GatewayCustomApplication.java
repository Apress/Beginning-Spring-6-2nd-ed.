package com.bsg6.chapter10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayCustomApplication {
    public static void main(String[] args) {
        SpringApplication.run(GatewayCustomApplication.class, args);
    }
}
